# MP1 代码——安装与使用（中文译文）

> 对应原文：[README.md](README.md)。本页完整翻译英文 README；补充说明标为“译注”。命令和版本号按本地原文保留，未执行安装或训练。

请阅读[项目指南中文版](../GUIDE.zh-CN.md)，了解作业要求、考核、截止日期与同学互评。本 README 包含运行说明和技术规则。原始材料包只有这两份说明文档。

以下所有命令都在 **`code/`** 目录下执行。数据和分词器已随包提供。无需 API 密钥、预训练权重或另外下载数据集；安装依赖后，训练和评估均可离线运行。

## 1. 安装

使用 **Python 3.12**。从解压后的材料包目录执行：

```bash
cd code
python -m venv .venv
source .venv/bin/activate
```

Windows PowerShell 改用 `.venv\Scripts\Activate.ps1` 激活环境。

为下面**一种**设备安装 PyTorch：

```bash
# Linux/Windows CPU：推荐，无需 GPU
python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cpu
```

如果使用 NVIDIA GPU 且驱动兼容，则**改用**：

```bash
python -m pip install torch==2.7.1 --index-url https://download.pytorch.org/whl/cu126
```

macOS 从默认 PyPI 源安装 `torch==2.7.1`，并使用 CPU 运行。安装 PyTorch 后，安装其余依赖并检查模型：

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
```

Linux CPU 命令已在 Python 3.12 和 PyTorch 2.7.1+cpu 下验证。Windows/macOS 的运行时间尚未测量。

> 译注：上一句是英文材料对其验证情况的说明，并不表示本次翻译执行了这些命令。当前工作区位于 `MP1_student_starter/` 的上一层，因此从当前目录进入代码目录应使用 `cd MP1_student_starter/code`。macOS 对应的 PyTorch 安装命令是 `python -m pip install torch==2.7.1`。

## 2. 训练与评估

**快速安装检查**——训练 10 步，再执行完整测试集评估：

```bash
python train.py --implementation model --steps 10 --run-dir runs/smoke
python evaluate.py --checkpoint runs/smoke/checkpoint.pt --split test
```

这用于检查整个流程能否运行；其分数**不是**完整基线结果。每次训练都需要一个新的输出目录。

**完整基线**——执行 1,200 次训练更新，再评估：

```bash
python train.py --implementation model --device cpu --threads 4 --seed 17 --run-dir runs/baseline
python evaluate.py --checkpoint runs/baseline/checkpoint.pt --device cpu --precision fp32 --split test
```

基线包含 4 个 GPT 模块，隐藏维度为 128，注意力头数为 4，共有 **1,088,256 个参数**；测试成绩约为 **2.10 BPB**。在参考硬件 Xeon Platinum 8457C 上使用 4 个线程，实测训练约需 **311 秒**，评分约需 **5.92 秒**，不含安装与加载时间。这些是参考测量结果，不是对笔记本运行时间的保证，也不是固定的时间上限。

**你的模型**——编辑 `student.py` 和相关辅助文件，然后运行：

```bash
python train.py --implementation student --seed 17 --eval-every 300 --run-dir runs/my-model
python evaluate.py --checkpoint runs/my-model/checkpoint.pt --split validation
# 测试之前先冻结最终方法：
python evaluate.py --checkpoint runs/my-model/checkpoint.pt --split test
```

训练会写入 `checkpoint.pt` 和 `metrics.json`。评估会写入 `test_cpu_fp32.json`（或对应设备/数据划分名称的文件）和逐窗口损失。应提交完整测试集 JSON 中的 **`bpb`**，不要提交 token 困惑度或验证集 BPB。默认评估精度为 FP32。GPU 运行时添加 `--device cuda`；训练可以使用 BF16，但用于排名的评估必须使用 FP32，并能在 CPU 上复现。提供的 CUDA 运行程序将 PyTorch 分配的显存限制在 20 GB；驱动开销另计。

## 3. 文件与模型接口

| 文件 | 用途 |
|---|---|
| `model.py`、`configs/baseline.json` | 可直接运行的基线；保留它们用于对比。 |
| `student.py`、`train.py` | 你的模型构造入口和训练方案；可按需添加辅助代码。 |
| `common.py`、`evaluate.py` | 固定的数据校验、窗口划分与评分逻辑；保持不变。 |
| `data/` | 提供的数据划分、分词器与数据哈希；保持不变。 |
| `tests/test_contract.py` | 检查模型的因果性、归一化、独立性与梯度。 |
| `RUN_LOG_TEMPLATE.csv` | 可选的实验日志模板。 |
| `PACKAGE_MANIFEST.json` | 发布文件哈希；路径相对于包含 `code/` 和 `guide/` 的材料包根目录。 |

- `build_model(config)` 返回一个具有 `context=256` 的 PyTorch 模型。
- 提供的训练器调用 `forward(ids)` 获得未经归一化的 logits；评分器调用 `predict_log_probs(ids)` 获得有限、已归一化的自然对数概率。两个接口的输出形状都必须是 `[batch, time, 2048]`。
- 在位置 t 的预测只能使用截至 t 的已观察前缀。独立窗口、样本和评分轮次之间都要重置临时状态。从训练数据得到的紧凑辅助数据可以跨窗口复用；根据评估前缀形成的状态不可以。
- 检查点会记录实现模块和配置。提交时需包含该模块及所有必要文件，以便评估器重建预测器。直接评估不需要优化器状态。
- 在指南限制内，可以调整训练长度、模型结构、优化器、正则化、基于自行训练所得权重的平均及模型集成。记录所有随机种子、已处理训练目标数、检查点来源链和搜索成本；复用检查点不会抹去其之前的训练成本。没有强制要求使用某个种子或达到某个提升幅度。

> 译注：当前包的 `GUIDE.md` 在根目录，并不存在 `guide/` 子目录；上表对发布清单路径的描述来自原文。

## 4. 基准与资源测量

**固定评分方式。** 协议为 `7506-mp1-wt2-v2`：WikiText-2 原始文本、仅在训练集上拟合的 BPE-2048 分词器、每个窗口含 256 个预测目标的独立窗口划分，并包含末尾不足长度的窗口。每个划分除第一个 token 外，其余每个目标恰好评分一次。输入窗口之间共享一个边界 token，但不传递状态。BPB 等于下一 token 的负对数概率之和（以 2 为底），除以整个划分的原始 UTF-8 字节数；分母也包含第一个 token 对应的字节。

| 数据划分 | 参与评分的目标数 | UTF-8 字节数 |
|---|---:|---:|
| 验证集 | 376,599 | 1,148,007 |
| 测试集 | 428,405 | 1,292,013 |

所有开发、检查点选择及混合方案选择都使用验证集。权重、统计量和检索条目必须仅来自训练文本。公开测试文本用于结果复现，不得用于方法调优。方法冻结后，可以多次评估同一个预测器，以进行计时或复现。这里的 token 困惑度不能直接与已发表的词级困惑度比较。

对同一个冻结的预测器测量以下三项限制：

- **CPU 时间 ≤ 基线的 5 倍。**
- **峰值内存 ≤ 4 GiB。**
- **未压缩的推理所需文件 ≤ 64 MiB。**

> 译注：当前英文 README 在这三项后没有给出具体测量命令、重复计时方式或峰值 RAM 采集步骤；本译文不补写未提供的官方流程。代码实际记录哪些指标，见[项目导读](../PROJECT_OVERVIEW.zh-CN.md)。

## 5. 准备提交与复现同学结果

[项目指南](../GUIDE.zh-CN.md)规定了截止日期与网站操作流程。你的不可变代码仓库中应包含：

- **报告：最多 10 页，包含图、表和参考文献。**
- **复现说明。**

最终网站提交必须链接到该代码和与之匹配的完整检查点文件包。网站会自动生成 Issue JSON。所有推理所需文件都应可下载，以便核验。

要核验另一位同学的结果，取得其准确代码版本和检查点，按照其安装说明操作，再使用提供的评估器运行冻结的模型：

```bash
python evaluate.py --checkpoint /path/to/peer-checkpoint.pt --device cpu --precision fp32 --split test --output peer-test.json
```

将复现 BPB 与报告分数进行比较。提交 **Peer Review Report（互评报告）** 时填写复现分数；可选择附上命令、环境、差异和证据/日志链接。差异由教师裁定。根据另行公布的评分政策，在七天评审期内确认的差异可获得额外加分。

## 6. 数据来源声明

WikiText-2 由 Stephen Merity、Caiming Xiong、James Bradbury 和 Richard Socher 在 [Pointer Sentinel Mixture Models](https://arxiv.org/abs/1609.07843) 中提出。文本由维基百科贡献者编写。[上游数据集](https://huggingface.co/datasets/Salesforce/wikitext)标明了 [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/) 和 [GNU 自由文档许可证](https://www.gnu.org/licenses/fdl-1.3.html)；重新分发数据时请保留这些声明。

提供的 `wikitext-2-raw-v1` 数据划分保留版本 `b08601e04326c79dfdd32d625aee71d232d685c3`。各行以换行符连接，并使用 UTF-8 编码；分词器仅在训练文本上拟合。数据哈希位于 `data/manifest.json`。这些数据声明不会给周围的课堂代码指定一个新的许可证。
