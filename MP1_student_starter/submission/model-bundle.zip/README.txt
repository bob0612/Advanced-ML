Extract into code/models. From code/: python evaluate.py --checkpoint models/final.pt --device cpu --precision fp32 --threads 4 --split test
See ../REPRODUCE.md and ../report/REPORT.pdf for exact setup and evidence. Other checkpoints are optional comparisons.
